# Simple Music Player - Vue JS | Неоморфизм / Neomorphism

A Pen created on CodePen.io. Original URL: [https://codepen.io/leon9208/pen/NWPyzzm](https://codepen.io/leon9208/pen/NWPyzzm).

